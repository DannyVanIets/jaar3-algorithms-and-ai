#ifndef CONSTANTS_H
#define CONSTANTS_H

const int WindowWidth  = 700;
const int WindowHeight = 400;


//defines the size of a team -- do not adjust
const int TeamSize = 5;



#endif