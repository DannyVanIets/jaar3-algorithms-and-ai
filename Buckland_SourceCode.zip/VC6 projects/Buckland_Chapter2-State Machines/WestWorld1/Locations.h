#ifndef LOCATIONS_H
#define LOCATIONS_H


enum location_type
{
  shack,
  goldmine,
  bank,
  saloon
};








#endif