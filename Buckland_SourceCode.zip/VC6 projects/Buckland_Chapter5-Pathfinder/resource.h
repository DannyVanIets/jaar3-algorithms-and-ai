//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by toolbar.rc
//
#define IDR_TOOLBAR1                    101
#define IDR_MENU1                       103
#define IDI_ICON1                       104
#define ID_BUTTON_STOP                  40001
#define ID_BUTTON_START                 40002
#define ID_BUTTON_OBSTACLE              40003
#define ID_BUTTON_WATER                 40004
#define ID_BUTTON_MUD                   40005
#define ID_BUTTON_END                   40006
#define ID_BUTTON_NORMAL                40007
#define ID_BUTTON_DFS                   40008
#define ID_BUTTON_BFS                   40009
#define ID_BUTTON_DIJKSTRA              40010
#define ID_BUTTON_ASTAR                 40011
#define IDM_VIEW_GRAPH                  40013
#define IDM_VIEW_TILES                  40014
#define ID_MENU_SAVEAS                  40019
#define ID_MENU_LOAD                    40020
#define ID_MENU_NEW                     40021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40015
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
